#pragma once

enum class OrderStatus
{
	Pending, 
	Shipped,
	Delivered
};


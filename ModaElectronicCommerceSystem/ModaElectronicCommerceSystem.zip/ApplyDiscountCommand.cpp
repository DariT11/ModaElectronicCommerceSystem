#include "ApplyDiscountCommand.h"

ApplyDiscountCommand::ApplyDiscountCommand(Client& cliet)
	:client(client)
{

}

void ApplyDiscountCommand::execute(System& system)
{
	//client.getCart().applyDiscount(client->getPoints());
}

#pragma once

namespace Constants
{
	static constexpr size_t EGN_LENGTH = 10;
	static constexpr size_t INITIAL_CAPACITY = 16;
	static constexpr size_t BUFFER_SIZE = 1024;
}
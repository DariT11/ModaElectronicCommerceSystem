#pragma once

enum class Role
{
	Any,
	Client,
	Bussiness,
	Administrator
};
#include <iostream>
#include "System.h"

using namespace std;

int main()
{
    cout << "Welcome to Darby-Moda online shop! :)" << endl;
    cout << endl;

    System system;
    system.start();
}